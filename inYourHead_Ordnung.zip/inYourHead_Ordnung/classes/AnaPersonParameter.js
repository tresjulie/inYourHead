export default class AnaPersonParameter {
  constructor(trigger, wellBeing) {
    this.trigger = trigger;
    this.wellBeing = wellBeing;
  }
}

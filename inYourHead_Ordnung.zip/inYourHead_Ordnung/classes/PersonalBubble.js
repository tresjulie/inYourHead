export default class PersonalBubble {
  constructor(color, direction) {
    this.color = color;
    this.direction = direction;
  }
}
